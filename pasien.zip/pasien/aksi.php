<?php
include "../koneksi.php";

$data = mysqli_query(
$conn,
"SELECT * FROM pasien"
);

?>

<!DOCTYPE html>
<html>
<head>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>

<div class="container mt-4">

<h2>Data Pasien</h2>

<a href="tambah.php" class="btn btn-primary mb-3">
Tambah Pasien
</a>

<table class="table table-bordered">

<tr>

<th>No</th>
<th>Nama</th>
<th>JK</th>
<th>Umur</th>
<th>Telepon</th>
<th>Aksi</th>

</tr>

<?php

$no=1;

while($d=mysqli_fetch_array($data)){

?>

<tr>

<td><?= $no++ ?></td>
<td><?= $d['nama_pasien'] ?></td>
<td><?= $d['jenis_kelamin'] ?></td>
<td><?= $d['umur'] ?></td>
<td><?= $d['no_telepon'] ?></td>

<td>

<a href="edit.php?id=<?= $d['id_pasien'] ?>" class="btn btn-warning">
Edit
</a>

<a href="hapus.php?id=<?= $d['id_pasien'] ?>" class="btn btn-danger">
Hapus
</a>

</td>

</tr>

<?php } ?>

</table>

</div>

</body>
</html>