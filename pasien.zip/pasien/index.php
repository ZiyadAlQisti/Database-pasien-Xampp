<?php
include 'koneksi.php';

$page = $_GET['page'] ?? 'dashboard';

/* ============================================================
   HELPER: escape semua input supaya lebih aman dari SQL Injection
   ============================================================ */
function clean($conn, $value)
{
    return mysqli_real_escape_string($conn, $value ?? '');
}

/* ============================================================
   TAMBAH DATA
   ============================================================ */
if (isset($_POST['simpan'])) {

    $tipe = $_POST['tipe'];

    if ($tipe == "pasien") {
        $nama = clean($conn, $_POST['nama']);
        $jk   = clean($conn, $_POST['jk']);
        $umur = clean($conn, $_POST['umur']);
        $telp = clean($conn, $_POST['telp']);

        mysqli_query($conn, "
            INSERT INTO pasien (nama_pasien, jenis_kelamin, umur, no_telepon)
            VALUES ('$nama', '$jk', '$umur', '$telp')
        ");
    }

    if ($tipe == "dokter") {
        $nama      = clean($conn, $_POST['nama']);
        $spesialis = clean($conn, $_POST['spesialis']);
        $telp      = clean($conn, $_POST['telp']);

        mysqli_query($conn, "
            INSERT INTO dokter (nama_dokter, spesialis, no_telepon)
            VALUES ('$nama', '$spesialis', '$telp')
        ");
    }

    if ($tipe == "obat") {
        $nama  = clean($conn, $_POST['nama']);
        $stok  = clean($conn, $_POST['stok']);
        $harga = clean($conn, $_POST['harga']);

        mysqli_query($conn, "
            INSERT INTO obat (nama_obat, stok, harga)
            VALUES ('$nama', '$stok', '$harga')
        ");
    }

    header("Location: index.php?page=" . $tipe);
    exit;
}

/* ============================================================
   UPDATE DATA
   ============================================================ */
if (isset($_POST['update'])) {

    $tipe = $_POST['tipe'];
    $id   = clean($conn, $_POST['id']);

    if ($tipe == "pasien") {
        $nama = clean($conn, $_POST['nama']);
        $jk   = clean($conn, $_POST['jk']);
        $umur = clean($conn, $_POST['umur']);
        $telp = clean($conn, $_POST['telp']);

        mysqli_query($conn, "
            UPDATE pasien SET
                nama_pasien='$nama',
                jenis_kelamin='$jk',
                umur='$umur',
                no_telepon='$telp'
            WHERE id_pasien='$id'
        ");
    }

    if ($tipe == "dokter") {
        $nama      = clean($conn, $_POST['nama']);
        $spesialis = clean($conn, $_POST['spesialis']);
        $telp      = clean($conn, $_POST['telp']);

        mysqli_query($conn, "
            UPDATE dokter SET
                nama_dokter='$nama',
                spesialis='$spesialis',
                no_telepon='$telp'
            WHERE id_dokter='$id'
        ");
    }

    if ($tipe == "obat") {
        $nama  = clean($conn, $_POST['nama']);
        $stok  = clean($conn, $_POST['stok']);
        $harga = clean($conn, $_POST['harga']);

        mysqli_query($conn, "
            UPDATE obat SET
                nama_obat='$nama',
                stok='$stok',
                harga='$harga'
            WHERE id_obat='$id'
        ");
    }

    /* --- UPDATE RIWAYAT / PEMERIKSAAN --- */
    if ($tipe == "pemeriksaan") {
        $pasien   = clean($conn, $_POST['pasien']);
        $dokter   = clean($conn, $_POST['dokter']);
        $keluhan  = clean($conn, $_POST['keluhan']);
        $diagnosa = clean($conn, $_POST['diagnosa']);
        $catatan  = clean($conn, $_POST['catatan']);

        mysqli_query($conn, "
            UPDATE pemeriksaan SET
                id_pasien='$pasien',
                id_dokter='$dokter',
                keluhan='$keluhan',
                diagnosa='$diagnosa',
                catatan='$catatan'
            WHERE id_pemeriksaan='$id'
        ");

        header("Location: index.php?page=riwayat");
        exit;
    }

    header("Location: index.php?page=" . $tipe);
    exit;
}

/* ============================================================
   HAPUS DATA
   ============================================================ */
if (isset($_GET['hapus'])) {

    $id     = clean($conn, $_GET['id']);
    $tabel  = $_GET['hapus'];

    if ($tabel == "pasien") {
        mysqli_query($conn, "DELETE FROM pasien WHERE id_pasien='$id'");
    }

    if ($tabel == "dokter") {
        mysqli_query($conn, "DELETE FROM dokter WHERE id_dokter='$id'");
    }

    if ($tabel == "obat") {
        mysqli_query($conn, "DELETE FROM obat WHERE id_obat='$id'");
    }

    /* --- HAPUS RIWAYAT / PEMERIKSAAN --- */
    if ($tabel == "pemeriksaan") {
        mysqli_query($conn, "DELETE FROM pemeriksaan WHERE id_pemeriksaan='$id'");
        header("Location: index.php?page=riwayat");
        exit;
    }

    header("Location: index.php?page=" . $tabel);
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Riwayat Pasien</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --clinic-teal: #0d9488;
            --clinic-teal-dark: #0f766e;
            --clinic-blue: #2563eb;
            --clinic-navy: #0b1f3a;
            --clinic-navy-2: #123058;
            --clinic-bg: #eef5f6;
            --clinic-danger: #e11d48;
        }

        * { font-family: 'Plus Jakarta Sans', 'Segoe UI', sans-serif; }

        body {
            background: var(--clinic-bg);
            background-image:
                radial-gradient(circle at 0% 0%, rgba(13,148,136,0.08), transparent 40%),
                radial-gradient(circle at 100% 0%, rgba(37,99,235,0.08), transparent 40%);
        }

        /* ===== SIDEBAR ===== */
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(180deg, var(--clinic-navy) 0%, var(--clinic-navy-2) 100%);
            padding: 24px 18px;
            color: white;
            position: sticky;
            top: 0;
            box-shadow: 4px 0 24px rgba(0,0,0,0.15);
        }

        .sidebar-brand {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 6px 8px 22px 8px;
            margin-bottom: 14px;
            border-bottom: 1px solid rgba(255,255,255,0.12);
        }

        .sidebar-brand .icon-badge {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            background: linear-gradient(135deg, var(--clinic-teal), var(--clinic-blue));
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            flex-shrink: 0;
            box-shadow: 0 6px 16px rgba(13,148,136,0.4);
        }

        .sidebar-brand .brand-text h3 {
            font-size: 16px;
            font-weight: 700;
            margin: 0;
            line-height: 1.2;
        }

        .sidebar-brand .brand-text small {
            color: rgba(255,255,255,0.55);
            font-size: 11px;
            letter-spacing: 0.5px;
        }

        .menu-label {
            text-transform: uppercase;
            font-size: 11px;
            letter-spacing: 1px;
            color: rgba(255,255,255,0.4);
            padding: 8px 12px;
            font-weight: 600;
        }

        .menu a {
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
            color: rgba(255,255,255,0.85);
            padding: 12px 14px;
            margin: 4px 0;
            border-radius: 12px;
            font-size: 14.5px;
            font-weight: 500;
            transition: all 0.25s ease;
            border: 1px solid transparent;
        }

        .menu a i {
            font-size: 17px;
            width: 20px;
            text-align: center;
        }

        .menu a:hover {
            background: rgba(255,255,255,0.08);
            color: #fff;
            transform: translateX(2px);
        }

        .menu a.active {
            background: linear-gradient(135deg, var(--clinic-teal), var(--clinic-blue));
            color: #fff;
            box-shadow: 0 6px 16px rgba(13,148,136,0.35);
            border-color: rgba(255,255,255,0.2);
        }

        /* ===== KONTEN ===== */
        .content-area {
            padding: 28px 34px;
        }

        .page-title {
            font-weight: 800;
            color: var(--clinic-navy);
            margin-bottom: 22px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .page-title i {
            color: var(--clinic-teal);
        }

        /* ===== DASHBOARD CARDS ===== */
        .stat-card {
            border: none;
            border-radius: 18px;
            padding: 26px;
            color: #fff;
            position: relative;
            overflow: hidden;
            box-shadow: 0 10px 25px rgba(0,0,0,0.08);
        }

        .stat-card .stat-icon {
            width: 52px;
            height: 52px;
            border-radius: 14px;
            background: rgba(255,255,255,0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            margin-bottom: 14px;
        }

        .stat-card h5 {
            font-weight: 500;
            opacity: 0.9;
            font-size: 14px;
            margin-bottom: 4px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .stat-card h1 {
            font-weight: 800;
            font-size: 2.4rem;
            margin: 0;
        }

        .stat-card.bg-pasien { background: linear-gradient(135deg, #0d9488, #14b8a6); }
        .stat-card.bg-dokter { background: linear-gradient(135deg, #2563eb, #3b82f6); }
        .stat-card.bg-obat   { background: linear-gradient(135deg, #7c3aed, #a855f7); }

        /* ===== CARDS (FORM) ===== */
        .cardx, .card {
            border-radius: 18px;
            border: 1px solid rgba(15,23,42,0.06);
        }

        .card h4 {
            font-weight: 700;
            color: var(--clinic-navy);
            font-size: 17px;
            margin-bottom: 18px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .card h4::before {
            content: "";
            width: 5px;
            height: 18px;
            border-radius: 4px;
            background: linear-gradient(180deg, var(--clinic-teal), var(--clinic-blue));
            display: inline-block;
        }

        .form-control, .form-select, select.form-control {
            border-radius: 10px;
            border: 1px solid #e2e8f0;
            padding: 10px 14px;
            font-size: 14.5px;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--clinic-teal);
            box-shadow: 0 0 0 3px rgba(13,148,136,0.15);
        }

        label {
            font-size: 13px;
            font-weight: 600;
            color: #475569;
            margin-bottom: 4px;
        }

        .btn {
            border-radius: 10px;
            font-weight: 600;
            font-size: 14px;
            padding: 9px 18px;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--clinic-teal), var(--clinic-blue));
            border: none;
        }

        .btn-primary:hover {
            background: linear-gradient(135deg, var(--clinic-teal-dark), #1d4ed8);
        }

        .btn-success {
            background: #059669;
            border: none;
        }

        .btn-warning {
            background: #f59e0b;
            border: none;
            color: #fff;
        }

        .btn-danger {
            background: var(--clinic-danger);
            border: none;
        }

        /* ===== TABLE ===== */
        .table-wrap {
            background: #fff;
            border-radius: 18px;
            padding: 6px;
            box-shadow: 0 8px 24px rgba(15,23,42,0.06);
            border: 1px solid rgba(15,23,42,0.05);
            overflow: hidden;
        }

        .table {
            margin-bottom: 0;
        }

        .table th {
            background: #f1f5f9;
            color: var(--clinic-navy);
            font-size: 12.5px;
            text-transform: uppercase;
            letter-spacing: 0.4px;
            font-weight: 700;
            border-bottom: none;
            padding: 14px 16px;
        }

        .table td {
            padding: 13px 16px;
            font-size: 14.5px;
            vertical-align: middle;
            color: #334155;
            border-color: #f1f5f9;
        }

        .table tbody tr:hover {
            background: #f8fafc;
        }

        .table td .btn, .table td a.btn {
            padding: 6px 12px;
            font-size: 13px;
        }
    </style>
</head>
<body>

<div class="container-fluid">
    <div class="row">

        <!-- SIDEBAR -->
        <div class="col-md-2 sidebar">
            <div class="sidebar-brand">
                <div class="icon-badge">🏥</div>
                <div class="brand-text">
                    <h3>Riwayat Pasien</h3>
                    <small>Sistem Manajemen Klinik</small>
                </div>
            </div>
            <div class="menu-label">Menu Utama</div>
            <div class="menu">
                <a href="index.php" class="<?= ($page == 'dashboard') ? 'active' : '' ?>"><i class="bi bi-grid-1x2-fill"></i> Dashboard</a>
                <a href="?page=pasien" class="<?= ($page == 'pasien') ? 'active' : '' ?>"><i class="bi bi-people-fill"></i> Pasien</a>
                <a href="?page=dokter" class="<?= ($page == 'dokter') ? 'active' : '' ?>"><i class="bi bi-heart-pulse-fill"></i> Dokter</a>
                <a href="?page=obat" class="<?= ($page == 'obat') ? 'active' : '' ?>"><i class="bi bi-capsule"></i> Obat</a>
                <a href="?page=riwayat" class="<?= ($page == 'riwayat') ? 'active' : '' ?>"><i class="bi bi-clipboard2-pulse-fill"></i> Riwayat Pasien</a>
            </div>
        </div>

        <!-- KONTEN -->
        <div class="col-md-10 content-area">

            <?php if ($page == "dashboard") {

                $p = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM pasien"));
                $d = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM dokter"));
                $o = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM obat"));
            ?>

            <h2 class="page-title"><i class="bi bi-grid-1x2-fill"></i> Dashboard</h2>

            <div class="row g-4">
                <div class="col-md-4">
                    <div class="stat-card bg-pasien">
                        <div class="stat-icon"><i class="bi bi-people-fill"></i></div>
                        <h5>Total Pasien</h5>
                        <h1><?= $p ?></h1>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="stat-card bg-dokter">
                        <div class="stat-icon"><i class="bi bi-heart-pulse-fill"></i></div>
                        <h5>Total Dokter</h5>
                        <h1><?= $d ?></h1>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="stat-card bg-obat">
                        <div class="stat-icon"><i class="bi bi-capsule"></i></div>
                        <h5>Total Obat</h5>
                        <h1><?= $o ?></h1>
                    </div>
                </div>
            </div>

            <?php } ?>


            <?php
            if ($page == "riwayat") {
                $tabel = "pemeriksaan";
            } else {
                $tabel = $page;
            }

            if ($page != "dashboard") {

                $kolom = [];

                if ($page == "pasien") {
                    $kolom = [
                        "nama_pasien"   => "Nama",
                        "jenis_kelamin" => "JK",
                        "umur"          => "Umur",
                        "no_telepon"    => "Telepon",
                    ];
                }

                if ($page == "dokter") {
                    $kolom = [
                        "nama_dokter" => "Nama",
                        "spesialis"   => "Spesialis",
                        "no_telepon"  => "Telepon",
                    ];
                }

                if ($page == "obat") {
                    $kolom = [
                        "nama_obat" => "Nama",
                        "stok"      => "Stok",
                        "harga"     => "Harga",
                    ];
                }

                if ($page == "riwayat") {
            ?>

            <h2 class="page-title"><i class="bi bi-clipboard2-pulse-fill"></i> Riwayat Pasien</h2>

            <!-- FORM TAMBAH RIWAYAT -->
            <div class="card shadow-sm p-4 mb-4">
                <h4>Tambah Riwayat Pemeriksaan</h4>
                <form method="post">
                    <div class="row">
                        <div class="col">
                            <label>Pasien</label>
                            <select name="pasien" class="form-control">
                                <?php
                                $x = mysqli_query($conn, "SELECT * FROM pasien");
                                while ($p = mysqli_fetch_assoc($x)) {
                                ?>
                                <option value="<?= $p['id_pasien'] ?>"><?= $p['nama_pasien'] ?></option>
                                <?php } ?>
                            </select>
                        </div>

                        <div class="col">
                            <label>Penyakit</label>
                            <select name="penyakit" class="form-control">
                                <?php
                                $x = mysqli_query($conn, "SELECT * FROM penyakit");
                                while ($p = mysqli_fetch_assoc($x)) {
                                ?>
                                <option value="<?= $p['id_penyakit'] ?>"><?= $p['nama_penyakit'] ?></option>
                                <?php } ?>
                            </select>
                        </div>

                        <div class="col d-flex align-items-end">
                            <button name="buatRiwayat" class="btn btn-primary">Simpan</button>
                        </div>
                    </div>
                </form>
            </div>

            <?php
                    if (isset($_POST['buatRiwayat'])) {

                        $pasien   = clean($conn, $_POST['pasien']);
                        $penyakit = clean($conn, $_POST['penyakit']);

                        $data = mysqli_fetch_assoc(
                            mysqli_query($conn, "SELECT * FROM penyakit WHERE id_penyakit='$penyakit'")
                        );

                        $idDokter = clean($conn, $data['id_dokter']);
                        $keluhan  = clean($conn, $data['nama_penyakit']);
                        $diagnosa = clean($conn, $data['diagnosa']);
                        $catatan  = clean($conn, $data['catatan']);

                        mysqli_query($conn, "
                            INSERT INTO pemeriksaan
                                (id_pasien, id_dokter, tanggal_pemeriksaan, keluhan, diagnosa, catatan)
                            VALUES
                                ('$pasien', '$idDokter', NOW(), '$keluhan', '$diagnosa', '$catatan')
                        ");
                    }
                    ?>

            <!-- FORM EDIT RIWAYAT -->
            <?php if (isset($_GET['edit_riwayat'])) {

                $idEdit = clean($conn, $_GET['edit_riwayat']);

                $editRiwayat = mysqli_fetch_assoc(
                    mysqli_query($conn, "SELECT * FROM pemeriksaan WHERE id_pemeriksaan='$idEdit'")
                );
            ?>

            <div class="card shadow-sm p-4 mb-4">
                <h4>Edit Riwayat Pasien</h4>
                <form method="post">
                    <input type="hidden" name="tipe" value="pemeriksaan">
                    <input type="hidden" name="id" value="<?= $editRiwayat['id_pemeriksaan'] ?>">

                    <div class="row">
                        <div class="col">
                            <label>Pasien</label>
                            <select name="pasien" class="form-control">
                                <?php
                                $x = mysqli_query($conn, "SELECT * FROM pasien");
                                while ($p = mysqli_fetch_assoc($x)) {
                                    $selected = ($p['id_pasien'] == $editRiwayat['id_pasien']) ? "selected" : "";
                                ?>
                                <option value="<?= $p['id_pasien'] ?>" <?= $selected ?>><?= $p['nama_pasien'] ?></option>
                                <?php } ?>
                            </select>
                        </div>

                        <div class="col">
                            <label>Dokter</label>
                            <select name="dokter" class="form-control">
                                <?php
                                $x = mysqli_query($conn, "SELECT * FROM dokter");
                                while ($dk = mysqli_fetch_assoc($x)) {
                                    $selected = ($dk['id_dokter'] == $editRiwayat['id_dokter']) ? "selected" : "";
                                ?>
                                <option value="<?= $dk['id_dokter'] ?>" <?= $selected ?>><?= $dk['nama_dokter'] ?></option>
                                <?php } ?>
                            </select>
                        </div>

                        <div class="col">
                            <label>Keluhan</label>
                            <input class="form-control" name="keluhan" value="<?= $editRiwayat['keluhan'] ?>">
                        </div>

                        <div class="col">
                            <label>Diagnosa</label>
                            <input class="form-control" name="diagnosa" value="<?= $editRiwayat['diagnosa'] ?>">
                        </div>

                        <div class="col">
                            <label>Catatan</label>
                            <input class="form-control" name="catatan" value="<?= $editRiwayat['catatan'] ?>">
                        </div>

                        <div class="col d-flex align-items-end">
                            <button name="update" class="btn btn-success">Update</button>
                        </div>
                    </div>
                </form>
            </div>

            <?php } ?>

            <div class="table-wrap">
            <table class="table table-hover mb-0">
                <tr>
                    <th>Pasien</th>
                    <th>Keluhan</th>
                    <th>Dokter</th>
                    <th>Diagnosa</th>
                    <th>Catatan</th>
                    <th>Aksi</th>
                </tr>

                <?php
                $data = mysqli_query($conn, "
                    SELECT
                        pm.id_pemeriksaan,
                        p.nama_pasien,
                        pm.keluhan,
                        d.nama_dokter,
                        pm.diagnosa,
                        pm.catatan
                    FROM pemeriksaan pm
                    JOIN pasien p ON p.id_pasien = pm.id_pasien
                    JOIN dokter d ON d.id_dokter = pm.id_dokter
                ");

                while ($d = mysqli_fetch_assoc($data)) {
                ?>
                <tr>
                    <td><?= $d['nama_pasien'] ?></td>
                    <td><?= $d['keluhan'] ?></td>
                    <td><?= $d['nama_dokter'] ?></td>
                    <td><?= $d['diagnosa'] ?></td>
                    <td><?= $d['catatan'] ?></td>
                    <td>
                        <a class="btn btn-warning"
                           href="?page=riwayat&edit_riwayat=<?= $d['id_pemeriksaan'] ?>">
                            <i class="bi bi-pencil-square"></i> Edit
                        </a>
                        <a class="btn btn-danger"
                           href="?page=riwayat&hapus=pemeriksaan&id=<?= $d['id_pemeriksaan'] ?>"
                           onclick="return confirm('Yakin ingin menghapus riwayat ini?');">
                            <i class="bi bi-trash3-fill"></i> Hapus
                        </a>
                    </td>
                </tr>
                <?php } ?>
            </table>
            </div>

            <?php
                } else {
            ?>

            <?php
                $pageIcons = [
                    'pasien' => 'bi-people-fill',
                    'dokter' => 'bi-heart-pulse-fill',
                    'obat'   => 'bi-capsule',
                ];
                $pageIcon = $pageIcons[$page] ?? 'bi-folder-fill';
            ?>
            <h2 class="page-title"><i class="bi <?= $pageIcon ?>"></i> <?= ucfirst($page) ?></h2>

            <!-- FORM TAMBAH -->
            <div class="card shadow-sm p-4 mb-4 cardx">
                <h4>Tambah Data <?= ucfirst($page) ?></h4>
                <form method="post">
                    <input type="hidden" name="tipe" value="<?= $page ?>">

                    <div class="row">
                        <?php if ($page == "pasien") { ?>
                        <div class="col">
                            <input class="form-control" name="nama" placeholder="Nama Pasien" required>
                        </div>
                        <div class="col">
                            <select class="form-control" name="jk" required>
                                <option value="">Pilih JK</option>
                                <option>Laki-laki</option>
                                <option>Perempuan</option>
                            </select>
                        </div>
                        <div class="col">
                            <input class="form-control" name="umur" type="number" placeholder="Umur" required>
                        </div>
                        <div class="col">
                            <input class="form-control" name="telp" placeholder="Telepon" required>
                        </div>
                        <?php } ?>

                        <?php if ($page == "dokter") { ?>
                        <div class="col">
                            <input class="form-control" name="nama" placeholder="Nama Dokter" required>
                        </div>
                        <div class="col">
                            <input class="form-control" name="spesialis" placeholder="Spesialis" required>
                        </div>
                        <div class="col">
                            <input class="form-control" name="telp" placeholder="Telepon" required>
                        </div>
                        <?php } ?>

                        <?php if ($page == "obat") { ?>
                        <div class="col">
                            <input class="form-control" name="nama" placeholder="Nama Obat" required>
                        </div>
                        <div class="col">
                            <input class="form-control" name="stok" placeholder="Stok" required>
                        </div>
                        <div class="col">
                            <input class="form-control" name="harga" placeholder="Harga" required>
                        </div>
                        <?php } ?>

                        <div class="col">
                            <button class="btn btn-primary" name="simpan">Tambah</button>
                        </div>
                    </div>
                </form>
            </div>

            <!-- FORM EDIT -->
            <?php if (isset($_GET['edit'])) {

                $id = clean($conn, $_GET['edit']);

                $dataedit = mysqli_fetch_assoc(
                    mysqli_query($conn, "SELECT * FROM $page WHERE id_$page='$id'")
                );
            ?>

            <div class="card shadow-sm p-4 mb-4">
                <h4>Edit Data</h4>
                <form method="post">
                    <input type="hidden" name="tipe" value="<?= $page ?>">
                    <input type="hidden" name="id" value="<?= $id ?>">

                    <div class="row">
                        <?php if ($page == "pasien") { ?>
                        <div class="col">
                            <input class="form-control" name="nama" value="<?= $dataedit['nama_pasien'] ?>">
                        </div>
                        <div class="col">
                            <input class="form-control" name="jk" value="<?= $dataedit['jenis_kelamin'] ?>">
                        </div>
                        <div class="col">
                            <input class="form-control" name="umur" value="<?= $dataedit['umur'] ?>">
                        </div>
                        <div class="col">
                            <input class="form-control" name="telp" value="<?= $dataedit['no_telepon'] ?>">
                        </div>
                        <?php } ?>

                        <?php if ($page == "dokter") { ?>
                        <div class="col">
                            <input class="form-control" name="nama" value="<?= $dataedit['nama_dokter'] ?>">
                        </div>
                        <div class="col">
                            <input class="form-control" name="spesialis" value="<?= $dataedit['spesialis'] ?>">
                        </div>
                        <div class="col">
                            <input class="form-control" name="telp" value="<?= $dataedit['no_telepon'] ?>">
                        </div>
                        <?php } ?>

                        <?php if ($page == "obat") { ?>
                        <div class="col">
                            <input class="form-control" name="nama" value="<?= $dataedit['nama_obat'] ?>">
                        </div>
                        <div class="col">
                            <input class="form-control" name="stok" value="<?= $dataedit['stok'] ?>">
                        </div>
                        <div class="col">
                            <input class="form-control" name="harga" value="<?= $dataedit['harga'] ?>">
                        </div>
                        <?php } ?>

                        <div class="col">
                            <button class="btn btn-success" name="update">Update</button>
                        </div>
                    </div>
                </form>
            </div>

            <?php } ?>

            <div class="table-wrap">
            <table class="table table-hover mb-0">
                <tr>
                    <?php foreach ($kolom as $k => $v) {
                        echo "<th>$v</th>";
                    } ?>
                    <th>Aksi</th>
                </tr>

                <?php
                $data = mysqli_query($conn, "SELECT * FROM $tabel");

                while ($d = mysqli_fetch_assoc($data)) {

                    echo "<tr>";

                    foreach ($kolom as $k => $v) {
                        echo "<td>" . $d[$k] . "</td>";
                    }

                    $id = $d["id_" . $page];
                ?>
                <td>
                    <a class="btn btn-warning" href="?page=<?= $page ?>&edit=<?= $id ?>"><i class="bi bi-pencil-square"></i> Edit</a>
                    <a class="btn btn-danger"
                       href="?page=<?= $page ?>&hapus=<?= $page ?>&id=<?= $id ?>"
                       onclick="return confirm('Yakin ingin menghapus data ini?');">
                        <i class="bi bi-trash3-fill"></i> Hapus
                    </a>
                </td>
                <?php
                    echo "</tr>";
                }
                ?>
            </table>
            </div>

            <?php
                }
            } ?>

        </div>
    </div>
</div>

</body>
</html>